
CLICK THE F1 HTML FILE.

Drag two different images for comparision.
Result will appear with several button options.
It highlights the difference between two images and display the accuracy.\

Image Gallery in the front page(f1.html) used to upload the images in the local system.

Image Quality in the front page(f1.html) used to view the RGB color variaions.

Image Slider in the front page(f1.html) used to compare two images instantly.

Image Magnifier in the front page(f1.html) used to Zoom the image uploaded.


